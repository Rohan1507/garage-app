export interface Vehicle {
  id: string;
  name: string;
  mobile: string;
  vn: string;
  make: string;
  model: string;
  date: string;
  km: string;
  dr: string;
  sdd: string;
  lob?: string;
  lb?: string;
  updatedAt?: number;
}

export interface User {
  uid: string;
  email: string;
  garageName: string;
}

export type Page = 'vehicles' | 'due';
export type AuthTab = 'login' | 'signup';
export type DueFilter = 'ov' | 'td' | 'wk' | 'mo';
export type SyncStatus = 'synced' | 'syncing' | 'offline' | 'error';
