import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Car, Calendar, WifiOff } from 'lucide-react';
import { Vehicle, User, Page, DueFilter, SyncStatus } from './types';
import { MAKES } from './constants';
import { getDays, formatDate, cn, getCachedVehicles, setCachedVehicles } from './utils';

import { onAuthStateChanged, signOut } from 'firebase/auth';
import {
  collection, doc, addDoc, deleteDoc, onSnapshot,
  query, orderBy, setDoc, getDoc,
} from 'firebase/firestore';
import { auth, db } from './firebase';

import Auth from './components/Auth';
import Header from './components/Header';
import VehicleCard from './components/VehicleCard';
import DueDashboard from './components/DueDashboard';
import { AddVehicleModal, DetailModal, ServiceModal, ImportModal } from './components/Modals';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [appLoading, setAppLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('synced');
  const [lastSync, setLastSync] = useState('Just now');
  const [isOffline, setIsOffline] = useState(false);
  const [page, setPage] = useState<Page>('vehicles');
  const [search, setSearch] = useState('');
  const [makeFilter, setMakeFilter] = useState('');
  const [dueFilter, setDueFilter] = useState<DueFilter>('ov');

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [serviceVehicle, setServiceVehicle] = useState<Vehicle | null>(null);
  const [editVehicle, setEditVehicle] = useState<Vehicle | null>(null);

  const unsubRef = useRef<(() => void) | null>(null);

  // Online/offline
  useEffect(() => {
    const off = () => { setIsOffline(true); setSyncStatus('offline'); };
    const on  = () => { setIsOffline(false); setSyncStatus('synced'); };
    window.addEventListener('offline', off);
    window.addEventListener('online', on);
    return () => { window.removeEventListener('offline', off); window.removeEventListener('online', on); };
  }, []);

  // Firebase Auth persistence
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const snap = await getDoc(doc(db, 'users', fbUser.uid));
          if (snap.exists()) {
            const p = snap.data();
            const u: User = { uid: fbUser.uid, email: fbUser.email!, garageName: p.garageName };
            setUser(u);
            startRealtimeSync(u.uid);
          }
        } catch {
          const cached = getCachedVehicles(fbUser.uid);
          if (cached) setVehicles(cached);
          setIsOffline(true); setSyncStatus('offline');
        }
      } else {
        setUser(null); setVehicles([]);
        if (unsubRef.current) { unsubRef.current(); unsubRef.current = null; }
      }
      setAppLoading(false);
    });
    return () => unsub();
  }, []);

  const startRealtimeSync = (uid: string) => {
    if (unsubRef.current) unsubRef.current();
    setSyncing(true); setSyncStatus('syncing');

    const cached = getCachedVehicles(uid);
    if (cached && cached.length > 0) setVehicles(cached);

    const q = query(collection(db, 'users', uid, 'vehicles'), orderBy('updatedAt', 'desc'));
    const unsub = onSnapshot(q,
      (snap) => {
        const data: Vehicle[] = snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<Vehicle, 'id'>) }));
        setVehicles(data);
        setCachedVehicles(uid, data);
        setSyncing(false); setSyncStatus('synced');
        setLastSync(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }));
      },
      (err) => {
        console.error('Firestore error:', err);
        setSyncing(false); setSyncStatus('error');
        const c = getCachedVehicles(uid);
        if (c) setVehicles(c);
      }
    );
    unsubRef.current = unsub;
  };

  const handleLogout = async () => {
    if (unsubRef.current) { unsubRef.current(); unsubRef.current = null; }
    await signOut(auth);
    setUser(null); setVehicles([]);
  };

  const vcol = (uid: string) => collection(db, 'users', uid, 'vehicles');
  const vdoc = (uid: string, id: string) => doc(db, 'users', uid, 'vehicles', id);

  const handleAddVehicle = async (v: Partial<Vehicle>) => {
    if (!user) return;
    const due = new Date(v.date!); due.setDate(due.getDate() + 90);
    setSyncing(true);
    try {
      await addDoc(vcol(user.uid), {
        name: v.name!, mobile: v.mobile!, vn: v.vn!, make: v.make!, model: v.model!,
        date: v.date!, km: v.km || '', dr: '', sdd: due.toISOString().split('T')[0],
        updatedAt: Date.now(),
      });
      setIsAddOpen(false);
    } catch { setSyncStatus('error'); }
    finally { setSyncing(false); }
  };

  const handleDeleteVehicle = async (v: Vehicle) => {
    if (!user || !confirm('Delete ' + v.name + '?')) return;
    setSyncing(true);
    try { await deleteDoc(vdoc(user.uid, v.id)); }
    catch { setSyncStatus('error'); }
    finally { setSyncing(false); }
  };

  const handleUpdateVehicle = async (v: Vehicle) => {
    if (!user) return;
    setSyncing(true);
    try {
      const { id, ...data } = v;
      await setDoc(vdoc(user.uid, id), { ...data, updatedAt: Date.now() });
    } catch { setSyncStatus('error'); }
    finally { setSyncing(false); setSelectedVehicle(null); }
  };

  const handleServiceComplete = async (v: Vehicle, oil: string, bill: string, km: string, nxt: string) => {
    if (!user) return;
    const updated = { ...v, lob: oil, lb: bill, km, sdd: nxt, date: new Date().toISOString().split('T')[0], updatedAt: Date.now() };
    setSyncing(true);
    try {
      const { id, ...data } = updated;
      await setDoc(vdoc(user.uid, id), data);
    } catch { setSyncStatus('error'); }
    finally { setSyncing(false); }

    const msg = `Hello ${v.name}! 🙏\n\n✅ *Service Completed* at ${user?.garageName}\n\n🏍️ *${v.vn}*\n${v.make} ${v.model}${km ? '\n📊 KM: *' + Number(km).toLocaleString() + '*' : ''}\n\n🛢️ Oil: *${oil}*\n💰 Bill: *₹${bill}*\n📅 Next Service: *${nxt}*\n\nThank you! 🙌`;
    window.open('https://wa.me/91' + v.mobile + '?text=' + encodeURIComponent(msg), '_blank');
    setServiceVehicle(null);
  };

  const handleRemind = (v: Vehicle) => {
    const d = getDays(v.sdd);
    const note = d !== null && d < 0
      ? '⚠️ Service is *OVERDUE* by ' + Math.abs(d) + ' days! Please visit us soon.'
      : d === 0 ? '🔔 Your vehicle service is due *TODAY*! Please visit us.'
      : d !== null && d <= 7 ? '⏰ Service is due in *' + d + ' days* on *' + formatDate(v.sdd) + '*.'
      : '📅 Next service: *' + formatDate(v.sdd) + '* (in ' + d + ' days)';
    const msg = 'Hello ' + v.name + '! 🙏\n\nReminder from *' + user?.garageName + '*\n\n🏍️ *' + v.vn + '* — ' + v.make + ' ' + v.model + (v.km ? '\n📊 KM: ' + Number(v.km).toLocaleString() : '') + '\n\n📅 Last Service: *' + formatDate(v.date) + '*\n📅 Due Date: *' + formatDate(v.sdd) + '*\n\n' + note + '\n\nCall us to book your appointment! 🙌';
    window.open('https://wa.me/91' + v.mobile + '?text=' + encodeURIComponent(msg), '_blank');
  };

  const handleSendAll = (filter: DueFilter) => {
    let list: Vehicle[] = [];
    if (filter === 'ov') list = vehicles.filter(v => (getDays(v.sdd) || 0) < 0);
    else if (filter === 'td') list = vehicles.filter(v => getDays(v.sdd) === 0);
    else if (filter === 'wk') list = vehicles.filter(v => { const d = getDays(v.sdd); return d !== null && d > 0 && d <= 7; });
    else list = vehicles.filter(v => { const d = getDays(v.sdd); return d !== null && d > 7 && d <= 30; });
    if (!list.length) return;
    let i = 0;
    const send = () => { if (i >= list.length) return; handleRemind(list[i++]); if (i < list.length) setTimeout(send, 800); };
    send();
  };

  const handleImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      if (!user) return;
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const raw = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]) as any[];
        const norm = (s: string) => String(s).toLowerCase().replace(/[\s_\-\.#]/g, '');
        const km: Record<string, string[]> = {
          name: ['name','customername','customer'], mobile: ['mobile','phone','contact','mobileno','phoneno'],
          vn: ['vehicleno','vehiclenumber','vno','regno','registrationno','registration'],
          make: ['make','brand','company'], model: ['model','vehiclemodel'],
          date: ['servicedate','date','lastservice'], km: ['km','odometer','currentkm','mileage'],
          sdd: ['nextservice','nextservicedate','duedate','nextdate'],
        };
        if (!raw.length) return;
        const mp: Record<string, string> = {};
        Object.keys(raw[0]).forEach(h => { const n = norm(h); for (const [k, a] of Object.entries(km)) { if (a.includes(n)) { mp[k] = h; break; } } });
        const rows = raw.map(r => {
          const dt = r[mp.date] || new Date().toISOString().split('T')[0];
          let sdd = r[mp.sdd] || ''; if (!sdd) { const d = new Date(dt); d.setDate(d.getDate()+90); sdd = d.toISOString().split('T')[0]; }
          return { name: String(r[mp.name]||'').trim(), mobile: String(r[mp.mobile]||'').trim().replace(/\D/g,'').slice(-10), vn: String(r[mp.vn]||'').trim().toUpperCase(), make: String(r[mp.make]||'').trim(), model: String(r[mp.model]||'').trim(), date: dt, km: String(r[mp.km]||'').trim(), sdd, dr: '', updatedAt: Date.now() };
        }).filter(r => r.name && r.mobile);
        if (rows.length > 0) {
          setSyncing(true);
          await Promise.all(rows.map(v => addDoc(vcol(user.uid), v)));
          setSyncing(false); setIsImportOpen(false);
          alert('Imported ' + rows.length + ' records!');
        }
      } catch { alert('Failed to read file'); }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleExport = () => {
    const data = vehicles.map((v, i) => ({ 'Sr': i+1, 'Name': v.name, 'Mobile': v.mobile, 'Vehicle No': v.vn, 'Make': v.make, 'Model': v.model, 'Last Service': v.date, 'Current KM': v.km, 'Next Due': v.sdd, 'Last Oil': v.lob||'', 'Last Bill': v.lb||'' }));
    const ws = XLSX.utils.json_to_sheet(data); const wbk = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wbk, ws, 'Vehicles');
    XLSX.writeFile(wbk, 'Garage_' + (user?.garageName.replace(/\s+/g,'_')) + '_' + new Date().toISOString().split('T')[0] + '.xlsx');
  };

  const filteredVehicles = useMemo(() => vehicles.filter(v => {
    const ms = !search || v.name.toLowerCase().includes(search.toLowerCase()) || v.mobile.includes(search) || v.vn.toLowerCase().includes(search.toLowerCase());
    const mm = !makeFilter || v.make === makeFilter;
    return ms && mm;
  }), [vehicles, search, makeFilter]);

  const overdueCount = vehicles.filter(v => (getDays(v.sdd) || 0) < 0).length;
  const dueSoonCount = vehicles.filter(v => { const d = getDays(v.sdd); return d !== null && d >= 0 && d <= 7; }).length;

  if (appLoading) {
    return (
      <div className="min-h-screen bg-bg flex flex-col items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }} className="w-12 h-12 border-4 border-acc/20 border-t-acc rounded-full mb-4" />
        <p className="text-txt2 text-sm font-bold tracking-widest">LOADING GARAGE...</p>
      </div>
    );
  }

  if (!user) return <Auth onSuccess={(u) => { setUser(u); startRealtimeSync(u.uid); }} />;

  return (
    <div className="min-h-screen bg-bg flex flex-col">
      <AnimatePresence>
        {isOffline && (
          <motion.div initial={{ y: -40 }} animate={{ y: 0 }} exit={{ y: -40 }} className="bg-gold/20 border-b border-gold/40 px-4 py-2 flex items-center gap-2 text-gold text-xs font-bold z-[200]">
            <WifiOff size={14} /> No internet — showing cached data. Changes will sync when back online.
          </motion.div>
        )}
      </AnimatePresence>

      <Header user={user} vehicleCount={vehicles.length} overdueCount={overdueCount} dueSoonCount={dueSoonCount}
        onLogout={handleLogout} onSync={() => user && startRealtimeSync(user.uid)}
        onImport={() => setIsImportOpen(true)} onExport={handleExport}
        search={search} onSearchChange={setSearch} makeFilter={makeFilter} onMakeFilterChange={setMakeFilter}
        makes={Object.keys(MAKES)} syncing={syncing} lastSync={lastSync} syncStatus={syncStatus} />

      <main className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {page === 'vehicles' ? (
            <motion.div key="v" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="p-3 pb-24">
              {filteredVehicles.length === 0 ? (
                <div className="text-center py-20 text-txt2">
                  <Car className="mx-auto mb-4 opacity-10" size={64} />
                  <p className="text-lg font-bold text-slate-400">No Vehicles Found</p>
                  <p className="text-sm">Tap the + button to add one</p>
                </div>
              ) : filteredVehicles.map(v => (
                <VehicleCard key={v.id} vehicle={v} onDetail={setSelectedVehicle} onEdit={setEditVehicle} onDelete={handleDeleteVehicle} onService={setServiceVehicle} onRemind={handleRemind} />
              ))}
            </motion.div>
          ) : (
            <motion.div key="d" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              <DueDashboard vehicles={vehicles} user={user} filter={dueFilter} onFilterChange={setDueFilter} onRemind={handleRemind} onService={setServiceVehicle} onSendAll={handleSendAll} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-s1 border-t border-bdr flex items-center justify-around pb-safe z-40">
        <button onClick={() => setPage('vehicles')} className={cn("flex-1 py-3 flex flex-col items-center gap-1 text-[10px] font-bold transition-colors", page === 'vehicles' ? "text-acc" : "text-txt2")}>
          <Car size={20} /> Vehicles
        </button>
        <div className="relative -top-5">
          <button onClick={() => setIsAddOpen(true)} className="w-14 h-14 rounded-2xl bg-gradient-to-br from-acc to-[#be123c] flex items-center justify-center text-white shadow-[0_6px_20px_rgba(225,29,72,0.5)] active:scale-90 transition-transform">
            <Plus size={28} strokeWidth={3} />
          </button>
        </div>
        <button onClick={() => setPage('due')} className={cn("flex-1 py-3 flex flex-col items-center gap-1 text-[10px] font-bold transition-colors", page === 'due' ? "text-acc" : "text-txt2")}>
          <Calendar size={20} /> Service Due
        </button>
      </nav>

      <AddVehicleModal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} onAdd={handleAddVehicle} />
      <DetailModal isOpen={!!selectedVehicle} onClose={() => setSelectedVehicle(null)} vehicle={selectedVehicle} onUpdate={handleUpdateVehicle} onService={(v) => { setSelectedVehicle(null); setServiceVehicle(v); }} onRemind={handleRemind} />
      <ServiceModal isOpen={!!serviceVehicle} onClose={() => setServiceVehicle(null)} vehicle={serviceVehicle} onComplete={handleServiceComplete} />
      <ImportModal isOpen={isImportOpen} onClose={() => setIsImportOpen(false)} onImport={handleImport} />
      {editVehicle && (
        <AddVehicleModal isOpen={!!editVehicle} onClose={() => setEditVehicle(null)}
          onAdd={async (v) => { await handleUpdateVehicle({ ...editVehicle, ...v } as Vehicle); setEditVehicle(null); }} />
      )}
    </div>
  );
}
