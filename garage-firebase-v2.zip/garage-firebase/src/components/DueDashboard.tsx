import React from 'react';
import { motion } from 'motion/react';
import { Calendar, MessageSquare, Phone, Bell, Wrench, ChevronRight } from 'lucide-react';
import { Vehicle, DueFilter, User } from '../types';
import { getDays, formatDate, cn } from '../utils';

interface DueDashboardProps {
  vehicles: Vehicle[];
  user: User;
  filter: DueFilter;
  onFilterChange: (f: DueFilter) => void;
  onRemind: (v: Vehicle) => void;
  onService: (v: Vehicle) => void;
  onSendAll: (f: DueFilter) => void;
}

export default function DueDashboard({
  vehicles,
  user,
  filter,
  onFilterChange,
  onRemind,
  onService,
  onSendAll
}: DueDashboardProps) {
  const now = new Date();
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const shortM = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  const overdue = vehicles.filter(v => (getDays(v.sdd) || 0) < 0).sort((a, b) => (getDays(a.sdd) || 0) - (getDays(b.sdd) || 0));
  const dueToday = vehicles.filter(v => getDays(v.sdd) === 0);
  const dueWeek = vehicles.filter(v => {
    const d = getDays(v.sdd);
    return d !== null && d > 0 && d <= 7;
  }).sort((a, b) => (getDays(a.sdd) || 0) - (getDays(b.sdd) || 0));
  const dueMonth = vehicles.filter(v => {
    const d = getDays(v.sdd);
    return d !== null && d > 7 && d <= 30;
  }).sort((a, b) => (getDays(a.sdd) || 0) - (getDays(b.sdd) || 0));

  let currentList: Vehicle[] = [];
  let title = '';
  let accentClass = '';
  let btnClass = '';

  switch (filter) {
    case 'ov': currentList = overdue; title = 'Overdue Service'; accentClass = 'border-l-acc'; btnClass = 'bg-acc/15 text-acc border-acc/30'; break;
    case 'td': currentList = dueToday; title = 'Due Today'; accentClass = 'border-l-gold'; btnClass = 'bg-gold/15 text-gold border-gold/30'; break;
    case 'wk': currentList = dueWeek; title = 'Due This Week'; accentClass = 'border-l-blue'; btnClass = 'bg-blue/15 text-blue border-blue/30'; break;
    case 'mo': currentList = dueMonth; title = 'Due This Month'; accentClass = 'border-l-green'; btnClass = 'bg-green/15 text-green border-green/30'; break;
  }

  return (
    <div className="p-3 pb-20">
      <div className="bg-gradient-to-br from-[#1e1b4b] via-[#312e81] to-[#1e1b4b] border border-indigo-500/35 rounded-2xl p-5 mb-4 relative overflow-hidden">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-indigo-500/25 blur-2xl" />
        <div className="absolute -bottom-5 -left-5 w-20 h-20 rounded-full bg-acc/15 blur-xl" />
        
        <div className="flex items-start justify-between mb-4 relative z-10">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[1.5px] text-indigo-300 mb-1">📅 Today's Date</div>
            <div className="text-2xl font-extrabold text-white leading-none">{now.getDate()} {months[now.getMonth()]} {now.getFullYear()}</div>
            <div className="text-xs text-indigo-300 mt-1">{days[now.getDay()]}</div>
          </div>
          <div className="text-[11px] font-bold text-indigo-400 bg-indigo-500/20 border border-indigo-500/30 px-3 py-1 rounded-full">
            🕐 {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 relative z-10">
          <div className="bg-acc/12 border border-acc/30 rounded-xl p-3">
            <div className="text-2xl font-extrabold text-acc leading-none">{overdue.length}</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-acc/75 mt-1">Overdue</div>
          </div>
          <div className="bg-gold/12 border border-gold/30 rounded-xl p-3">
            <div className="text-2xl font-extrabold text-gold leading-none">{dueToday.length}</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-gold/75 mt-1">Due Today</div>
          </div>
          <div className="bg-blue/12 border border-blue/30 rounded-xl p-3">
            <div className="text-2xl font-extrabold text-blue leading-none">{dueWeek.length}</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-blue/75 mt-1">This Week</div>
          </div>
          <div className="bg-green/12 border border-green/30 rounded-xl p-3">
            <div className="text-2xl font-extrabold text-green leading-none">{dueMonth.length}</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-green/75 mt-1">This Month</div>
          </div>
        </div>
      </div>

      <div className="flex gap-2 mb-4 overflow-x-auto pb-1 no-scrollbar">
        <button onClick={() => onFilterChange('ov')} className={cn("shrink-0 px-4 py-2 rounded-full border-1.5 border-bdr text-xs font-bold transition-all", filter === 'ov' ? "border-acc bg-acc/12 text-acc" : "text-txt2")}>🔴 Overdue {overdue.length}</button>
        <button onClick={() => onFilterChange('td')} className={cn("shrink-0 px-4 py-2 rounded-full border-1.5 border-bdr text-xs font-bold transition-all", filter === 'td' ? "border-gold bg-gold/12 text-gold" : "text-txt2")}>🟡 Today {dueToday.length}</button>
        <button onClick={() => onFilterChange('wk')} className={cn("shrink-0 px-4 py-2 rounded-full border-1.5 border-bdr text-xs font-bold transition-all", filter === 'wk' ? "border-blue bg-blue/12 text-blue" : "text-txt2")}>🔵 Week {dueWeek.length}</button>
        <button onClick={() => onFilterChange('mo')} className={cn("shrink-0 px-4 py-2 rounded-full border-1.5 border-bdr text-xs font-bold transition-all", filter === 'mo' ? "border-green bg-green/12 text-green" : "text-txt2")}>📅 Month {dueMonth.length}</button>
      </div>

      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-extrabold uppercase tracking-wider text-txt2">{title}</h3>
        {currentList.length > 0 && (
          <button 
            onClick={() => onSendAll(filter)}
            className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-bold active:scale-95 transition-transform", btnClass)}
          >
            <MessageSquare size={12} /> Send All ({currentList.length})
          </button>
        )}
      </div>

      {currentList.length === 0 ? (
        <div className="text-center py-12 text-txt2">
          <Calendar className="mx-auto mb-3 opacity-20" size={48} />
          <p className="font-bold text-sm text-slate-400">All Clear ✅</p>
          <p className="text-xs">No vehicles in this category</p>
        </div>
      ) : (
        currentList.map(v => {
          const d = getDays(v.sdd);
          const isOv = d !== null && d < 0;
          const isTd = d === 0;
          const countdownTxt = isOv ? `${Math.abs(d)} days overdue` : isTd ? '🔥 Due Today!' : d === 1 ? 'Due Tomorrow' : `Due in ${d} days`;
          
          return (
            <motion.div 
              key={v.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn("bg-s1 border-1.5 border-bdr rounded-2xl p-4 mb-3 relative overflow-hidden", accentClass)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center font-extrabold shrink-0", isOv ? "bg-acc/15 text-acc" : isTd ? "bg-gold/15 text-gold" : "bg-blue/15 text-blue")}>
                    {v.name[0].toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-white truncate">{v.name}</div>
                    <div className="text-[10px] text-txt2 mt-0.5">📱 {v.mobile}</div>
                    <div className="inline-block text-[9px] font-bold text-acc bg-acc/10 px-1.5 py-0.5 rounded mt-1 tracking-wider">{v.vn}</div>
                  </div>
                </div>
                <div className={cn("text-xs font-extrabold text-right", isOv ? "text-acc" : isTd ? "text-gold" : "text-blue")}>
                  {countdownTxt}
                </div>
              </div>

              <div className="flex items-center gap-2 mb-3">
                <span className="text-[10px] font-bold bg-acc2/20 text-indigo-400 px-2 py-0.5 rounded">{v.make}</span>
                <span className="text-[11px] text-txt2">{v.model}</span>
                {v.km && <span className="text-[10px] text-txt2">· {Number(v.km).toLocaleString()} km</span>}
              </div>

              <div className="flex items-center gap-0 bg-bg rounded-xl p-2.5 mb-3">
                <div className="flex-1 text-center">
                  <div className="text-[9px] font-bold uppercase text-txt2 mb-1">Last Service</div>
                  <div className="text-[11px] font-bold text-white">{formatDate(v.date)}</div>
                </div>
                <div className="px-2 text-txt2 opacity-30"><ChevronRight size={14} /></div>
                <div className="flex-1 text-center">
                  <div className="text-[9px] font-bold uppercase text-txt2 mb-1">Today</div>
                  <div className="text-[11px] font-bold text-indigo-300">{now.getDate()} {shortM[now.getMonth()]}</div>
                </div>
                <div className="px-2 text-txt2 opacity-30"><ChevronRight size={14} /></div>
                <div className="flex-1 text-center">
                  <div className="text-[9px] font-bold uppercase text-txt2 mb-1">Due Date</div>
                  <div className={cn("text-[11px] font-bold", isOv ? "text-acc" : isTd ? "text-gold" : "text-green")}>{formatDate(v.sdd)}</div>
                </div>
              </div>

              <div className="flex gap-2">
                <button onClick={() => window.location.href = `tel:${v.mobile}`} className="flex-1 py-2 rounded-xl bg-blue/12 text-blue font-bold text-[10px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform"><Phone size={11} /> Call</button>
                <button onClick={() => window.open(`https://wa.me/91${v.mobile}`, '_blank')} className="flex-1 py-2 rounded-xl bg-green/12 text-green font-bold text-[10px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform"><MessageSquare size={11} /> Chat</button>
                <button onClick={() => onRemind(v)} className="flex-1 py-2 rounded-xl bg-gold/12 text-gold font-bold text-[10px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform"><Bell size={11} /> Remind</button>
                <button onClick={() => onService(v)} className="flex-1 py-2 rounded-xl bg-violet-500/12 text-violet-400 font-bold text-[10px] flex items-center justify-center gap-1.5 active:scale-95 transition-transform"><Wrench size={11} /> Service</button>
              </div>
            </motion.div>
          );
        })
      )}
    </div>
  );
}
