import React from 'react';
import { Phone, Bell, Wrench, Trash2, Edit3 } from 'lucide-react';
import { Vehicle } from '../types';
import { cn, getDays } from '../utils';

interface VehicleCardProps {
  key?: string | number;
  vehicle: Vehicle;
  onDetail: (v: Vehicle) => void;
  onEdit: (v: Vehicle) => void;
  onDelete: (v: Vehicle) => void | Promise<void>;
  onService: (v: Vehicle) => void;
  onRemind: (v: Vehicle) => void;
}

export default function VehicleCard({
  vehicle,
  onDetail,
  onEdit,
  onDelete,
  onService,
  onRemind
}: VehicleCardProps) {
  const days = getDays(vehicle.sdd);
  const isOverdue = days !== null && days < 0;
  const isDueSoon = days !== null && days >= 0 && days <= 7;

  return (
    <div 
      onClick={() => onDetail(vehicle)}
      className={cn(
        "bg-s1 border-1.5 border-bdr rounded-2xl p-4 mb-3 cursor-pointer active:scale-[0.985] transition-transform",
        isOverdue && "border-l-4 border-l-acc",
        isDueSoon && "border-l-4 border-l-gold"
      )}
    >
      <div className="flex items-start justify-between mb-2">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-bold text-[15px] text-white">{vehicle.name}</h3>
            {isOverdue && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-acc/20 text-acc">Overdue</span>}
            {days === 0 && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gold/20 text-gold">Due Today</span>}
            {isDueSoon && days! > 0 && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gold/20 text-gold">In {days}d</span>}
            {!isOverdue && !isDueSoon && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-green/15 text-green">OK</span>}
          </div>
          <div className="text-xs text-txt2 mt-0.5">{vehicle.mobile}</div>
          <div className="text-xs font-bold text-[#f43f5e] tracking-[1.5px] mt-1 uppercase">{vehicle.vn}</div>
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={(e) => { e.stopPropagation(); onEdit(vehicle); }}
            className="p-2 rounded-lg bg-blue/10 text-blue active:scale-90 transition-transform"
          >
            <Edit3 size={14} />
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); onDelete(vehicle); }}
            className="p-2 rounded-lg bg-acc/10 text-acc active:scale-90 transition-transform"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      <div className="inline-block text-[11px] font-bold bg-acc2/20 text-[#818cf8] px-2.5 py-1 rounded-lg mb-3">
        {vehicle.make} · {vehicle.model}
      </div>

      <div className="flex gap-2">
        <button 
          onClick={(e) => { e.stopPropagation(); window.location.href = `tel:${vehicle.mobile}`; }}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-blue/15 text-blue font-bold text-[11px] active:scale-95 transition-transform"
        >
          <Phone size={12} /> Call
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); onRemind(vehicle); }}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-green/12 text-green font-bold text-[11px] active:scale-95 transition-transform"
        >
          <Bell size={12} /> Remind
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); onService(vehicle); }}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-violet-500/15 text-violet-400 font-bold text-[11px] active:scale-95 transition-transform"
        >
          <Wrench size={12} /> Service
        </button>
      </div>
    </div>
  );
}
