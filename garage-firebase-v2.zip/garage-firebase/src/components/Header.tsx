import React from 'react';
import { motion } from 'motion/react';
import { Car, RefreshCw, LogOut, FileSpreadsheet, Download, Search, Wifi, WifiOff, AlertCircle } from 'lucide-react';
import { User, SyncStatus } from '../types';
import { cn } from '../utils';

interface HeaderProps {
  user: User;
  vehicleCount: number;
  overdueCount: number;
  dueSoonCount: number;
  onLogout: () => void;
  onSync: () => void;
  onImport: () => void;
  onExport: () => void;
  search: string;
  onSearchChange: (val: string) => void;
  makeFilter: string;
  onMakeFilterChange: (val: string) => void;
  makes: string[];
  syncing: boolean;
  lastSync: string;
  syncStatus: SyncStatus;
}

export default function Header({
  user, vehicleCount, overdueCount, dueSoonCount,
  onLogout, onSync, onImport, onExport,
  search, onSearchChange, makeFilter, onMakeFilterChange, makes,
  syncing, lastSync, syncStatus,
}: HeaderProps) {
  const statusDot = syncStatus === 'synced' ? 'bg-green'
    : syncStatus === 'syncing' ? 'bg-blue animate-pulse'
    : syncStatus === 'offline' ? 'bg-gold'
    : 'bg-acc'; // error

  const statusText = syncStatus === 'synced' ? `Synced · ${lastSync}`
    : syncStatus === 'syncing' ? 'Syncing...'
    : syncStatus === 'offline' ? 'Offline — cached data'
    : 'Sync error — tap refresh';

  return (
    <div className="bg-s1 border-b border-bdr p-3 sticky top-0 z-50">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-acc2 to-acc flex items-center justify-center shrink-0">
            <Car className="text-white w-5 h-5" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-[15px] font-extrabold tracking-wider text-white leading-none">{user.garageName.toUpperCase()}</h2>
            <div className="flex items-center gap-1.5 mt-1">
              <div className={cn("w-1.5 h-1.5 rounded-full", statusDot)} />
              <span className="text-[10px] text-txt2 font-semibold">{statusText}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={onSync} className={cn("p-2 rounded-xl border border-bdr bg-blue/10 text-blue active:scale-90 transition-transform", syncing && "animate-spin")}>
            <RefreshCw size={16} />
          </button>
          <button onClick={onImport} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-acc2/50 bg-acc2/10 text-acc2 font-bold text-xs active:scale-95 transition-transform">
            <Download size={14} /> Import
          </button>
          <button onClick={onExport} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-green bg-green/10 text-green font-bold text-xs active:scale-95 transition-transform">
            <FileSpreadsheet size={14} /> Excel
          </button>
          <button onClick={onLogout} className="p-2 rounded-xl border border-bdr bg-acc/10 text-acc active:scale-90 transition-transform">
            <LogOut size={16} />
          </button>
        </div>
      </div>

      <div className="text-[11px] text-txt2 mb-3">
        {vehicleCount} vehicles
        {overdueCount > 0 && <span className="text-acc"> · {overdueCount} overdue</span>}
        {dueSoonCount > 0 && <span className="text-gold"> · {dueSoonCount} due soon</span>}
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-txt2" size={14} />
          <input type="text" value={search} onChange={e => onSearchChange(e.target.value)}
            placeholder="Search name, phone, vehicle no..."
            className="w-full bg-bg border border-bdr rounded-xl py-2 pl-9 pr-3 text-sm text-white focus:outline-none focus:border-acc transition-colors" />
        </div>
        <select value={makeFilter} onChange={e => onMakeFilterChange(e.target.value)}
          className="bg-bg border border-bdr rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-acc transition-colors min-w-[110px]">
          <option value="">All Makes</option>
          {makes.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>
    </div>
  );
}
