import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Car, ArrowRight, Eye, EyeOff, Loader } from 'lucide-react';
import { AuthTab, User } from '../types';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';

interface AuthProps {
  onSuccess: (user: User) => void;
}

export default function Auth({ onSuccess }: AuthProps) {
  const [tab, setTab] = useState<AuthTab>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [resetMode, setResetMode] = useState(false);

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPw, setLoginPw] = useState('');

  const [signupGn, setSignupGn] = useState('');
  const [signupEm, setSignupEm] = useState('');
  const [signupPw, setSignupPw] = useState('');
  const [signupCf, setSignupCf] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPw) return setError('Enter email and password');
    setLoading(true); setError('');
    try {
      const cred = await signInWithEmailAndPassword(auth, loginEmail.trim(), loginPw);
      const snap = await getDoc(doc(db, 'users', cred.user.uid));
      if (!snap.exists()) throw new Error('no-profile');
      const data = snap.data();
      onSuccess({ uid: cred.user.uid, email: cred.user.email!, garageName: data.garageName });
    } catch (err: any) {
      const c = err.code || err.message;
      if (c === 'auth/invalid-credential' || c === 'auth/wrong-password' || c === 'auth/user-not-found') setError('Invalid email or password');
      else if (c === 'auth/too-many-requests') setError('Too many attempts. Reset your password or try later.');
      else if (c === 'auth/network-request-failed') setError('No internet. Check your connection.');
      else setError('Login failed. Try again.');
    } finally { setLoading(false); }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupGn || !signupEm || !signupPw) return setError('Fill all fields');
    if (signupPw.length < 6) return setError('Password must be at least 6 characters');
    if (signupPw !== signupCf) return setError('Passwords do not match');
    setLoading(true); setError('');
    try {
      const cred = await createUserWithEmailAndPassword(auth, signupEm.trim(), signupPw);
      await setDoc(doc(db, 'users', cred.user.uid), {
        email: cred.user.email,
        garageName: signupGn.trim(),
        createdAt: Date.now(),
      });
      onSuccess({ uid: cred.user.uid, email: cred.user.email!, garageName: signupGn.trim() });
    } catch (err: any) {
      const c = err.code;
      if (c === 'auth/email-already-in-use') setError('Email already registered. Login instead.');
      else if (c === 'auth/weak-password') setError('Password too weak. Use at least 6 characters.');
      else if (c === 'auth/network-request-failed') setError('No internet. Check your connection.');
      else setError('Signup failed. Try again.');
    } finally { setLoading(false); }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail) return setError('Enter your email first');
    setLoading(true); setError('');
    try {
      await sendPasswordResetEmail(auth, loginEmail.trim());
      setSuccess('Reset email sent! Check your inbox.'); setResetMode(false);
    } catch { setError('Could not send. Check the address.'); }
    finally { setLoading(false); }
  };

  const inp = "w-full bg-bg border border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc transition-colors placeholder:text-txt2/50";
  const btn = "w-full py-3.5 bg-gradient-to-br from-acc to-[#be123c] rounded-xl text-white font-bold text-sm shadow-[0_4px_20px_rgba(225,29,72,0.35)] active:scale-95 transition-transform flex items-center justify-center gap-2 disabled:opacity-70";

  return (
    <div className="min-h-screen flex items-center justify-center p-5 bg-[radial-gradient(ellipse_at_20%_50%,rgba(67,56,202,0.2)_0%,transparent_60%),radial-gradient(ellipse_at_80%_20%,rgba(225,29,72,0.12)_0%,transparent_60%),#0f172a]">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-acc2 to-acc flex items-center justify-center shadow-[0_0_50px_rgba(225,29,72,0.5)] mx-auto mb-4">
            <Car className="text-white w-10 h-10" strokeWidth={2.5} />
          </div>
          <h1 className="text-2xl font-extrabold tracking-widest text-white">GARAGE MANAGER</h1>
          <p className="text-txt2 text-xs mt-1">Smart vehicle service tracking</p>
        </div>

        <div className="bg-s1 border border-bdr rounded-[20px] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.5)]">
          <div className="flex bg-bg rounded-xl p-1 mb-6">
            {(['login', 'signup'] as AuthTab[]).map(t => (
              <button key={t} onClick={() => { setTab(t); setError(''); setSuccess(''); setResetMode(false); }}
                className={`flex-1 py-2 rounded-lg font-bold text-sm transition-all ${tab === t ? 'bg-acc text-white shadow-lg' : 'text-txt2 hover:text-txt'}`}>
                {t === 'login' ? 'Login' : 'Sign Up'}
              </button>
            ))}
          </div>

          {error && <div className="mb-4 p-3 bg-acc/10 border border-acc/30 rounded-xl text-acc text-xs font-semibold text-center">{error}</div>}
          {success && <div className="mb-4 p-3 bg-green/10 border border-green/30 rounded-xl text-green text-xs font-semibold text-center">{success}</div>}

          {tab === 'login' ? (
            <form onSubmit={resetMode ? handleReset : handleLogin} className="space-y-4">
              {resetMode && <p className="text-xs text-txt2 text-center">Enter your email to get a reset link.</p>}
              <div>
                <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Email</label>
                <input type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} className={inp} placeholder="your@email.com" autoComplete="email" />
              </div>
              {!resetMode && (
                <div>
                  <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Password</label>
                  <div className="relative">
                    <input type={showPw ? 'text' : 'password'} value={loginPw} onChange={e => setLoginPw(e.target.value)} className={`${inp} pr-10`} placeholder="••••••••" autoComplete="current-password" />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-txt2">
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <button type="button" onClick={() => { setResetMode(true); setError(''); setSuccess(''); }} className="text-[10px] text-acc/70 hover:text-acc mt-1.5 transition-colors">
                    Forgot password?
                  </button>
                </div>
              )}
              <button disabled={loading} className={btn}>
                {loading ? <><Loader size={16} className="animate-spin" /> Processing...</> : resetMode ? 'Send Reset Email' : <>Login <ArrowRight size={16} /></>}
              </button>
              {resetMode && <button type="button" onClick={() => { setResetMode(false); setError(''); }} className="w-full text-xs text-txt2 hover:text-txt py-1">← Back to login</button>}
            </form>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Garage Name</label>
                <input type="text" value={signupGn} onChange={e => setSignupGn(e.target.value)} className={inp} placeholder="e.g. Sharma Auto Works" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Email</label>
                <input type="email" value={signupEm} onChange={e => setSignupEm(e.target.value)} className={inp} placeholder="your@email.com" autoComplete="email" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Password</label>
                  <input type="password" value={signupPw} onChange={e => setSignupPw(e.target.value)} className={inp} placeholder="Min 6" autoComplete="new-password" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Confirm</label>
                  <input type="password" value={signupCf} onChange={e => setSignupCf(e.target.value)} className={inp} placeholder="Repeat" autoComplete="new-password" />
                </div>
              </div>
              <button disabled={loading} className={btn}>
                {loading ? <><Loader size={16} className="animate-spin" /> Creating...</> : <>Create Account <ArrowRight size={16} /></>}
              </button>
            </form>
          )}
          <p className="text-center text-[10px] text-txt2 mt-5">🔒 Secured with Firebase Authentication</p>
        </div>
      </motion.div>
    </div>
  );
}
