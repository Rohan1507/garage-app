import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Car, Phone, Calendar, Wrench, MessageSquare, Save, Download, FileText, Bell } from 'lucide-react';
import { Vehicle, User } from '../types';
import { MAKES, OILS } from '../constants';
import { formatDate, getDays, getNextServiceDate } from '../utils';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

const Modal = ({ isOpen, onClose, title, subtitle, children }: ModalProps) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/75 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="relative w-full max-w-lg bg-s1 rounded-t-3xl sm:rounded-3xl p-6 max-h-[93vh] overflow-y-auto shadow-2xl border-t border-bdr sm:border"
        >
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-xl font-extrabold text-white">{title}</h3>
              {subtitle && <p className="text-xs text-txt2 mt-0.5">{subtitle}</p>}
            </div>
            <button onClick={onClose} className="p-2 rounded-xl bg-bg border border-bdr text-txt2 active:scale-90 transition-transform">
              <X size={18} />
            </button>
          </div>
          {children}
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

// --- ADD VEHICLE MODAL ---
export function AddVehicleModal({ isOpen, onClose, onAdd }: { isOpen: boolean, onClose: () => void, onAdd: (v: Partial<Vehicle>) => void }) {
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [vn, setVn] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [km, setKm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !mobile || !vn || !make || !model) return;
    onAdd({ name, mobile, vn: vn.toUpperCase(), make, model, date, km });
    setName(''); setMobile(''); setVn(''); setMake(''); setModel(''); setKm('');
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add Vehicle" subtitle="Fill customer details">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Customer Name *</label>
          <input required type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc" placeholder="Full name" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Mobile *</label>
            <input required type="tel" maxLength={10} value={mobile} onChange={e => setMobile(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc" placeholder="10-digit" />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Vehicle No *</label>
            <input required type="text" value={vn} onChange={e => setVn(e.target.value.toUpperCase())} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc" placeholder="MH12AB1234" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Make *</label>
            <select required value={make} onChange={e => { setMake(e.target.value); setModel(''); }} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc">
              <option value="">Select</option>
              {Object.keys(MAKES).map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Model *</label>
            <select required value={model} onChange={e => setModel(e.target.value)} disabled={!make} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc disabled:opacity-50">
              <option value="">{make ? 'Select' : 'Pick make first'}</option>
              {make && MAKES[make].map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Service Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc" />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Current KM</label>
            <input type="number" value={km} onChange={e => setKm(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-white focus:outline-none focus:border-acc" placeholder="e.g. 12000" />
          </div>
        </div>
        <button type="submit" className="w-full py-3.5 bg-gradient-to-br from-acc to-[#be123c] rounded-xl text-white font-bold text-sm shadow-lg active:scale-95 transition-transform mt-2">Add Vehicle →</button>
      </form>
    </Modal>
  );
}

// --- VEHICLE DETAIL MODAL ---
export function DetailModal({ isOpen, onClose, vehicle, onUpdate, onService, onRemind }: { isOpen: boolean, onClose: () => void, vehicle: Vehicle | null, onUpdate: (v: Vehicle) => void, onService: (v: Vehicle) => void, onRemind: (v: Vehicle) => void }) {
  const [km, setKm] = useState('');
  const [sdd, setSdd] = useState('');

  useEffect(() => {
    if (vehicle) {
      setKm(vehicle.km || '');
      setSdd(vehicle.sdd || '');
    }
  }, [vehicle]);

  if (!vehicle) return null;

  const days = getDays(vehicle.sdd);
  const isOv = days !== null && days < 0;
  const isTd = days === 0;
  const isSn = days !== null && days > 0 && days <= 7;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Details">
      <div className="bg-bg border border-bdr rounded-2xl p-4 mb-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-acc2 to-acc flex items-center justify-center text-xl font-extrabold text-white shrink-0 shadow-lg">
            {vehicle.name[0].toUpperCase()}
          </div>
          <div>
            <div className="font-bold text-lg text-white leading-none">{vehicle.name}</div>
            <div className="text-xs text-txt2 mt-1">{vehicle.mobile}</div>
            <div className="text-xs font-bold text-[#f43f5e] tracking-[1.5px] mt-1 uppercase">{vehicle.vn}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 border-t border-s1 pt-4">
          <div className="space-y-0.5"><div className="text-[9px] font-bold text-txt2 uppercase tracking-wider">Vehicle</div><div className="text-xs font-semibold text-white">{vehicle.make} {vehicle.model}</div></div>
          <div className="space-y-0.5"><div className="text-[9px] font-bold text-txt2 uppercase tracking-wider">Service Date</div><div className="text-xs font-semibold text-white">{formatDate(vehicle.date)}</div></div>
          {vehicle.km && <div className="space-y-0.5"><div className="text-[9px] font-bold text-txt2 uppercase tracking-wider">Current KM</div><div className="text-xs font-semibold text-white">{Number(vehicle.km).toLocaleString()} km</div></div>}
          {vehicle.lob && <div className="space-y-0.5"><div className="text-[9px] font-bold text-txt2 uppercase tracking-wider">Last Oil</div><div className="text-xs font-semibold text-white">{vehicle.lob}</div></div>}
          {vehicle.lb && <div className="space-y-0.5"><div className="text-[9px] font-bold text-txt2 uppercase tracking-wider">Last Bill</div><div className="text-xs font-semibold text-white">₹{vehicle.lb}</div></div>}
        </div>
      </div>

      {isOv && <div className="p-3 rounded-xl bg-acc/10 border border-acc/30 text-acc text-xs font-bold mb-4 text-center">🔴 Service overdue by {Math.abs(days!)} days! Visit soon.</div>}
      {isTd && <div className="p-3 rounded-xl bg-gold/10 border border-gold/30 text-gold text-xs font-bold mb-4 text-center">⚠️ Service due TODAY!</div>}
      {isSn && <div className="p-3 rounded-xl bg-gold/10 border border-gold/30 text-gold text-xs font-bold mb-4 text-center">⏰ Service in {days} days ({vehicle.sdd})</div>}
      {!isOv && !isTd && !isSn && <div className="p-3 rounded-xl bg-green/10 border border-green/30 text-green text-xs font-bold mb-4 text-center">✅ Next service: {vehicle.sdd} ({days} days away)</div>}

      <div className="grid grid-cols-2 gap-2 mb-6">
        <button onClick={() => window.location.href = `tel:${vehicle.mobile}`} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-blue/15 text-blue font-bold text-xs active:scale-95 transition-transform"><Phone size={14} /> Call</button>
        <button onClick={() => window.open(`https://wa.me/91${vehicle.mobile}`, '_blank')} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-green/12 text-green font-bold text-xs active:scale-95 transition-transform"><MessageSquare size={14} /> WhatsApp</button>
        <button onClick={() => onRemind(vehicle)} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-gold/12 text-gold font-bold text-xs active:scale-95 transition-transform"><Bell size={14} /> Remind</button>
        <button onClick={() => onService(vehicle)} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-acc/15 text-acc font-bold text-xs active:scale-95 transition-transform"><Wrench size={14} /> Service</button>
      </div>

      <div className="border-t border-bdr pt-5">
        <h4 className="text-[10px] font-bold text-txt2 uppercase tracking-wider mb-3">Update Info</h4>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-[9px] font-bold text-txt2 uppercase tracking-wider mb-1">Current KM</label>
            <input type="number" value={km} onChange={e => setKm(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-acc" />
          </div>
          <div>
            <label className="block text-[9px] font-bold text-txt2 uppercase tracking-wider mb-1">Next Service</label>
            <input type="date" value={sdd} onChange={e => setSdd(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-acc" />
          </div>
        </div>
        <button onClick={() => onUpdate({ ...vehicle, km, sdd })} className="w-full py-3 bg-gradient-to-br from-acc2 to-blue rounded-xl text-white font-bold text-sm shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2"><Save size={16} /> Save Changes</button>
      </div>
    </Modal>
  );
}

// --- LOG SERVICE MODAL ---
export function ServiceModal({ isOpen, onClose, vehicle, onComplete }: { isOpen: boolean, onClose: () => void, vehicle: Vehicle | null, onComplete: (v: Vehicle, oil: string, bill: string, km: string, nxt: string) => void }) {
  const [oil, setOil] = useState('');
  const [bill, setBill] = useState('');
  const [km, setKm] = useState('');
  const [nxt, setNxt] = useState(getNextServiceDate());

  useEffect(() => {
    if (vehicle) setKm(vehicle.km || '');
  }, [vehicle]);

  if (!vehicle) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Log Service">
      <div className="bg-acc/5 border border-acc/20 rounded-2xl p-4 flex items-center gap-4 mb-5">
        <div className="w-11 h-11 rounded-xl bg-acc/15 flex items-center justify-center shrink-0"><Wrench className="text-acc" size={20} /></div>
        <div>
          <div className="font-bold text-sm text-white">{vehicle.name}</div>
          <div className="text-[11px] text-txt2 mt-0.5">{vehicle.vn} · {vehicle.make} {vehicle.model}</div>
        </div>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Oil Brand *</label>
          <select required value={oil} onChange={e => setOil(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-sm text-white focus:outline-none focus:border-acc">
            <option value="">Select oil brand</option>
            {OILS.map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Bill Amount (₹) *</label>
            <input required type="number" value={bill} onChange={e => setBill(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-sm text-white focus:outline-none focus:border-acc" placeholder="e.g. 450" />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Odometer KM</label>
            <input type="number" value={km} onChange={e => setKm(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-sm text-white focus:outline-none focus:border-acc" placeholder="Current KM" />
          </div>
        </div>
        <div>
          <label className="block text-[10px] font-bold text-txt2 uppercase tracking-wider mb-1.5">Next Service Date</label>
          <input type="date" value={nxt} onChange={e => setNxt(e.target.value)} className="w-full bg-bg border-1.5 border-bdr rounded-xl p-3 text-sm text-white focus:outline-none focus:border-acc" />
        </div>
        <button onClick={() => onComplete(vehicle, oil, bill, km, nxt)} className="w-full py-4 bg-gradient-to-br from-green to-[#128c7e] rounded-xl text-white font-bold text-sm shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2 mt-2"><MessageSquare size={18} /> Complete & Send WhatsApp</button>
      </div>
    </Modal>
  );
}

// --- IMPORT MODAL ---
export function ImportModal({ isOpen, onClose, onImport }: { isOpen: boolean, onClose: () => void, onImport: (file: File) => void }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Import from Excel" subtitle="Upload .xlsx or .csv file">
      <div 
        onClick={() => document.getElementById('imp-file')?.click()}
        className="border-2 border-dashed border-bdr rounded-2xl p-10 text-center cursor-pointer hover:border-acc2 transition-colors mb-4"
      >
        <div className="text-txt2 mb-3 flex justify-center"><Download size={36} strokeWidth={1.5} /></div>
        <div className="font-bold text-sm text-white mb-1">Tap to choose file</div>
        <div className="text-xs text-txt2">Supports .xlsx, .xls, .csv</div>
        <input type="file" id="imp-file" accept=".xlsx,.xls,.csv" className="hidden" onChange={e => e.target.files?.[0] && onImport(e.target.files[0])} />
      </div>
      <div className="bg-acc2/10 border border-acc2/25 rounded-xl p-3 text-[10px] text-indigo-300 leading-relaxed">
        <strong>📋 Expected columns (any order):</strong><br/>
        Name · Mobile · Vehicle No · Make · Model · Service Date · KM · Next Service
      </div>
    </Modal>
  );
}
