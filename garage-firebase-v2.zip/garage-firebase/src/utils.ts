import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getDays(ds: string | undefined): number | null {
  if (!ds) return null;
  const d = new Date(ds);
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  return Math.floor((d.getTime() - t.getTime()) / 86400000);
}

export function formatDate(ds: string | undefined): string {
  if (!ds) return '—';
  const [y, m, d] = ds.split('-');
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${d} ${months[parseInt(m) - 1]} ${y}`;
}

export function getNextServiceDate(): string {
  const d = new Date();
  d.setDate(d.getDate() + 90);
  return d.toISOString().split('T')[0];
}

// Cache recent data locally for faster loading
const LOCAL_CACHE_KEY = 'gm_vehicle_cache';

export function getCachedVehicles(uid: string) {
  try {
    const raw = localStorage.getItem(`${LOCAL_CACHE_KEY}_${uid}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCachedVehicles(uid: string, data: any) {
  try {
    localStorage.setItem(`${LOCAL_CACHE_KEY}_${uid}`, JSON.stringify(data));
  } catch {}
}

export function clearCache(uid: string) {
  localStorage.removeItem(`${LOCAL_CACHE_KEY}_${uid}`);
}
