# Garage Manager — Firebase Edition 🔥

Cross-device vehicle service tracking with real-time sync, Firebase Auth, and Firestore.

---

## What's New (v2.0)

| Feature | Before | After |
|---|---|---|
| Authentication | Plaintext passwords in localStorage | Firebase Auth (encrypted) |
| Data storage | Browser-only localStorage | Cloud Firestore (cross-device) |
| Real-time sync | Manual refresh | Live onSnapshot — instant updates on all devices |
| Offline support | None | Cached data shown, auto-syncs when back online |
| Password reset | No | "Forgot password?" email flow built in |
| Security | Passwords readable in DevTools | User data isolated by Firebase UID rules |
| Multi-device | Impossible | Login anywhere, same data everywhere |

---

## Setup (5 minutes)

### 1. Create Firebase project
Go to https://console.firebase.google.com → Add project → name it.

### 2. Enable Email/Password Auth
Build → Authentication → Get Started → Email/Password → Enable → Save

### 3. Create Firestore Database
Build → Firestore Database → Create database → Production mode → choose region → Done

### 4. Deploy Security Rules
In Firestore → Rules tab, paste the contents of `firestore.rules` → Publish

### 5. Get your config
Project Settings (gear icon) → General → Your apps → Web icon (</>)
Register app → copy the firebaseConfig values

### 6. Configure environment
    cp .env.example .env
Fill in all VITE_FIREBASE_* values from your Firebase config.

### 7. Install and run
    npm install
    npm run dev

---

## How Real-Time Sync Works

    Device A adds a vehicle
           ↓
       Firestore (cloud)
           ↓
    Device B sees it instantly

Uses Firebase onSnapshot() — a persistent WebSocket that pushes changes
to all logged-in devices in real time, no polling or manual refresh needed.

---

## Security Model

- Each user has a unique Firebase UID
- All data stored at: users/{uid}/vehicles/{vehicleId}
- Firestore Rules prevent any cross-user data access
- Passwords are NEVER stored — Firebase Auth handles everything

---

## Offline Support

- Data is cached in localStorage after each sync
- Yellow banner shown when offline, cached data displayed
- Auto-reconnects and syncs when internet returns

---

## Firestore Data Structure

    users/
      {uid}/
        garageName, email, createdAt
        vehicles/
          {vehicleId}/
            name, mobile, vn, make, model
            date, sdd, km, lob, lb, updatedAt

---

## Build for Production

    npm run build
    # Deploy dist/ to Netlify, Vercel, or Firebase Hosting
